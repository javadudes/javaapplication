package com.comcast.cable.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrangeController {

    @RequestMapping("/v1/orange")
    public String greetingv1() {
        return "Hello orange";
    }

    @RequestMapping("/v2/orange")
    public String greetingv2() {
        return "Hello orange";
    }
}
